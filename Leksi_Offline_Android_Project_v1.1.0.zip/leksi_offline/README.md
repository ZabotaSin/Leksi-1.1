# Leksi Offline — v1.1.0

A standalone offline Android flashcard app built with Kotlin and Jetpack Compose.

## v1.1.0 updates

- The home-screen daily challenge now contains **20 randomized prompts** instead of a short fixed sequence.
- Daily challenge mixes flashcards, multiple-choice quiz questions, typed answers, and a pair-finding challenge.
- Prompt selection is weighted: cards marked as not learned are more likely to appear; learned cards remain in rotation but appear less often.
- Standard flashcard review is shuffled each time a study session starts. It includes all unlearned cards and a smaller random sample of learned cards; if all cards are learned, the full set is reviewed.
- Deck color can be changed from the palette icon on the deck detail screen.
- Version bumped to 1.1.0.

## Build with GitHub Actions

1. Upload this project ZIP to the root of a GitHub repository, or extract its contents into the repository root.
2. The included `.github/workflows/build-apk.yml` workflow runs on pushes to `main`/`master`, and can also be started manually from the Actions tab.
3. Download the `Leksi-debug-APK` artifact from a successful workflow run.
4. Extract the artifact and install `app-debug.apk` on an Android device.

## CSV format

The included `leksi_template.csv` uses the columns `set,front,back,note,learned`.

The app is designed for offline use. All decks and cards are stored locally on the device.
